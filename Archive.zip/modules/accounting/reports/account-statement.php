<?php
// Account Statement is essentially the same as General Ledger
// Redirect to ledger.php
header('Location: ledger.php');
exit;
?>
