document.addEventListener('DOMContentLoaded', function () {
    // No active scripts
});
