<?php
header('Location: public/landing.html');
exit;
